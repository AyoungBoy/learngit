package cn.edu.cslg.calculator;

import android.content.Context;
import android.widget.Toast;

/**
 * Created by Administrator on 2016/3/10 0010.
 */
public class ComputeResult {

    public static final String ERROR_ZERO="ERROR";

    private double firstNumber;
    private double secondNumber;
    private String operator;
    private double result;

    public ComputeResult(double firstNumber,double secondNumber,String operator){
        this.firstNumber=firstNumber;
        this.secondNumber=secondNumber;
        this.operator=operator;
    }

    public String compute(){
        switch (operator){
            case "+":
                result=firstNumber+secondNumber;
                break;
            case "-":
                result=firstNumber-secondNumber;
                break;
            case "*":
                result=firstNumber*secondNumber;
                break;
            case "/":
                if(secondNumber==0){
                    return ERROR_ZERO;
                }else{
                    result=firstNumber/secondNumber;
                }
                break;
        }
        return String.valueOf(result);
    }

}
