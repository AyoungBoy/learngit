package cn.edu.cslg.calculator;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends Activity {

    private EditText firstNumberEdt;
    private Spinner operatorSpinner;
    private EditText secondNumberEdt;
    private Button computeBtn;
    private TextView resultText;
    private String firstNumber;
    private String secondNumber;
    private String operator;
    private AlertDialog.Builder errDialog;


    private String[] operators=new String[]{
          "+","-","*","/"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        init();
        computeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getResult();
            }
        });
    }

    private void getResult() {
        resultText.setText("");
        firstNumber=firstNumberEdt.getText().toString();
        secondNumber=secondNumberEdt.getText().toString();
        Log.i("info", firstNumber + "  " + secondNumber);
        errDialog = new AlertDialog.Builder(MainActivity.this);
        errDialog.setTitle(R.string.error);
        errDialog.setPositiveButton(R.string.ensure, null);
        if(firstNumber.equals("")||firstNumber==null||
                secondNumber==null||secondNumber.equals("")){
            errDialog.setMessage(R.string.error_figure_null);
            errDialog.show();
        }else{
            ComputeResult cr=new ComputeResult(Double.parseDouble(firstNumber),
                    Double.parseDouble(secondNumber),(String)operatorSpinner.getSelectedItem());
            String result=cr.compute();
            if(result.equals(ComputeResult.ERROR_ZERO)){
                errDialog.setMessage(R.string.error_zero);
                errDialog.show();
            }else{
                resultText.setText(result);
            }
        }
    }

    private void init() {
        firstNumberEdt= (EditText) findViewById(R.id.first_number);
        operatorSpinner= (Spinner) findViewById(R.id.operator);
        secondNumberEdt= (EditText) findViewById(R.id.second_number);
        computeBtn= (Button) findViewById(R.id.compute);
        resultText= (TextView) findViewById(R.id.result);
        ArrayAdapter adapter=new ArrayAdapter(this,android.R.layout.simple_spinner_item,operators);
        operatorSpinner.setAdapter(adapter);
    }

}
